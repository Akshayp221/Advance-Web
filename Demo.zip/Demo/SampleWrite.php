<?php 

        $dom = new DOMDocument("1.0","utf-8");

		$root = $dom->createElement('students');
		$student_node = $dom->createElement('student');

	    $child_node_no = $dom->createElement('no', 1);
		$student_node->appendChild($child_node_no);

        $child_node_name = $dom->createElement('name', "mahesh");
		$student_node->appendChild($child_node_name);

        $child_node_address = $dom->createElement('address', "pune");
		$student_node->appendChild($child_node_address);

		$dom->appendChild($root);
        
		$dom->save('SampleWrite.xml');
		
       	header("location:SampleWrite.xml")

?>