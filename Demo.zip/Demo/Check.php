<?php

 if ($_GET["myData"]["username"] == "mahesh")
 {
     //Means Availablie
    echo "true";
 }
 else
 {
    //Means Not Availablie
    echo "false";
 }
  //echo "Hello ". $_GET["myData"]["username"];
  //echo print_r($_GET);
  //echo "hello";  
?>