<?php 
    if(isset($_POST["btnLogin"]))
    {
        session_start();
        if($_POST["uname"]=="mahesh" && $_POST["password"]=="mahesh@123")
        {
            //Means User is in role of admin
            $_SESSION["uname"] = $_POST["uname"];
            $_SESSION["role"] = "admin";
            header("location:99DemoDashboard.php");
        }
        else
        {
            //Means User is in role of user
            $_SESSION["uname"] = $_POST["uname"];
            $_SESSION["role"] = "user";
            header("location:99DemoProfile.php");
        }
    }
    else
    {
        echo "Login Here:";
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
</head>
<body>
    <form action="99DemoLogin.php" method="POST">
        <input type="text" name="uname" required="required">
        <input type="text" name="password" required="required">
        <input type="submit" name="btnLogin" value="Login">
    </form>
</body>
</html>