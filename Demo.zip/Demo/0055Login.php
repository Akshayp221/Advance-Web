<?php 
    if(isset($_POST["btnSubmit"]))
    {
       $uname =  $_POST["uname"]   ;
       $password =  $_POST["password"];
       if($uname == "mahesh" && $password=="mahesh@123")
       {
         session_start();
         $_SESSION["uname"] = $uname;
         header("location:0054Demo.php");
       }
       else
       {
           echo "UName / PWD is incorrect!";
       }
    }
    else
    {
        //DO Nothing
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
</head>
<body>
    <form action="0055Login.php" method="POST">
        <h4>User Name</h4> 
        <input type="text" name="uname" id="uname">
        
        <h4>Password</h4> 
        <input type="password" name="password" id="password">

        <input type="submit" value="Sign In" name="btnSubmit" id="btnSubmit">
    </form>
</body>
</html>