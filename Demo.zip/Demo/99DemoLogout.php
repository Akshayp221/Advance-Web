<?php
    session_start();
    if(isset($_SESSION["uname"]))
    {
        unset($_SESSION["role"]);
        unset($_SESSION["uname"]);
        header("location:99DemoLogin.php");
    }

?>