<?php

    if(isset($_GET["Name"]))
    {
        echo "<h1> Welcome " . $_GET["Name"]  . "</h1>";
        echo "<h1> from " . $_GET["Address"]  . "</h1>";
    }
    else
    {
        echo "Pls send query string";
    }

?>