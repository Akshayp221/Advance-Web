<?php 
    if(isset($_REQUEST["btnSubmit"]))
    {
        echo "You have come using proper Channel";
    }
    else
    {
        echo "pls. Visit through register page";
        header("location:0044Demo.html");
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Test</title>
</head>
<body>

    <?php 
        // <h1> 
        //     echo "Hi";
        // </h1>
    ?>

    <h1> 
        <?php
            echo "Hi ". $_REQUEST["FName"] ;
        ?>
    </h1>

    <?php
            echo "<h2>". " from ". $_REQUEST["Address"] ."</h2>";
    ?>
    

    <br>   
    
    <br>    
    <br>    
    <?php
            echo print_r($_REQUEST);
    ?>

</body>
</html>










