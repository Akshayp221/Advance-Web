function redirect(url)
{
    window.location.href = url;
}

function setLS(key, value)
{
 window.localStorage.setItem(key, value);
}

function getLS(key)
{
 return window.localStorage.getItem(key);
}

function removeLS(key)
{
 window.localStorage.removeItem(key);
}