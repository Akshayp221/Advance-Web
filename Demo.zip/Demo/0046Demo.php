

<?php 
   // if(isset($_REQUEST["btnSubmit"]))
   if(isset($_POST["btnSubmit"]))
    {
        echo "You have come using proper Channel<br/>";
        echo "<h1>". " Hi ". $_POST["FName"] ."</h1>";
        echo "<h2>". " from ". $_POST["Address"] ."</h2>";
        // echo "<h1>". " Hi ". $_REQUEST["FName"] ."</h1>";
        // echo "<h2>". " from ". $_REQUEST["Address"] ."</h2>";
    }
    else
    {
        echo "pls. Visit through register page";
        echo '<script> window.setTimeout(function(){ window.location.href="0047Demo.html"; },"2000"); </script>';
    }
?>










