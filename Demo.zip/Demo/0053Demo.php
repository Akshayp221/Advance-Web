<?php

        $con =  mysqli_connect("localhost","root","manager","karad");
        $result  =  mysqli_query($con,"select * from Emp");
        $data =  '[';
        while ($currentRecord = mysqli_fetch_row($result)) {
        $data = $data. '{'. 
                    '"No"'. ':' .$currentRecord[0]   .','.
                    '"Name"'.':"' .$currentRecord[1] .'",'.
                    '"Address"'.':"' .$currentRecord[2]  .'"'.
                 '},';
        }

        $data  = rtrim($data,',');

        $data = $data. ']';

        header("content-type:application/json");
        echo $data;

        mysqli_close($con);
?>