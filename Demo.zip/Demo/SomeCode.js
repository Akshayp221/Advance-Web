    var  counter = 0;

    keepCounting();
    function keepCounting()
      {
            counter = counter + 1;
            postMessage(counter);
            window.setTimeout("keepCounting()",1000);  
      }