<?php
    session_start();
    
    $token = 0;
    $balance = 0;

    if($_SESSION["balance"])
    {
        if(isset($_POST["btn"])) 
        {
            $bal = $_SESSION["balance"];
            $bal = $bal - $_POST["debitamount"];

            $_SESSION["balance"] = $bal;
            
            
            $cd  = $_SESSION["count"] ;
            $cd = $cd + 199;
            $_SESSION["count"]  = $cd;
            $token = $cd;

            $balance = $bal;

        }
        else
        {
            $balance = $_SESSION["balance"];
            
            $c  = $_SESSION["count"] ;
            $c = $c + 1;
            $_SESSION["count"]  = $c;
            $token = $c;
        }
    }  
    else
    {
        $_SESSION["balance"] = 1000;
        $_SESSION["count"] = 954;
        $token = $_SESSION["count"];
        $balance = $_SESSION["balance"];
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Transaction</title>
</head>
<body>
    <form action="0056Demo.php" method="POST">
        <input type="hidden" name="token" id="token" value="<?php echo $token ?>">
        Balance: <input type="text" name="balance" id="balance" value="<?php echo $balance ?>"><br>
        Amount to debit: <input value="0" type="text" name="debitamount" id="debitamount">
        <br>
        <input type="submit" name="btn" id="btn" value="Debit">
    </form>
</body>
</html>