<?php 
    if(isset($_POST["btn"]))
    {
        $item1 = $_POST["item1"];
        $item2 = $_POST["item2"];
        
        setcookie("item1", $item1,time() + 3600,"/");
        setcookie("item2", $item2,time() + 3600,"/");

        header("location:0058Demo.php");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Set Cookie</title>
</head>
<body>
    <form action="0057Demo.php" method="POST">
        <h1>Your preferences about subject:</h1>
            Preference 1: <input type="text" name="item1" id="item1"><br>
            Preference 2: <input type="text" name="item2" id="item2"><br>
            <input type="submit" name="btn" id="btn" value="Store and Redirect">
        <br>
    </form>
</body>
</html>