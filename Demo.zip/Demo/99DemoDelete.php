<?php
    session_start();
    if(isset($_SESSION["uname"]))
    {
        if($_SESSION["role"] == "admin")
        {
            echo "delete from users where No = " . $_GET["No"] ;

            // echo "<script>alert(" .  
            //                     "delete from users where No = " . $_GET["No"] .
            //         ")()</script>";

            //echo "<script>alert('hi');</script>";
                    
            //header("location: 99DemoDashboard.php");
        }
        else
        {
            header("location:99DemoLogin.php");    
        }
    }
    else
    {
        header("location:99DemoLogin.php");
    }
    


?>