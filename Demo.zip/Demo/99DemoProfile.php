<?php
    session_start();
    if(isset($_SESSION["uname"]))
    {
        if($_SESSION["role"] == "user")
        {
            
        }
        else
        {
            header("location:99DemoLogin.php");    
        }
    }
    else
    {
        header("location:99DemoLogin.php");
    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="">
        <input type="hidden" name="no" value="<?php echo $_SESSION["uname"]?>"><!--Put No Here -->
        <input type="text" name="uname" value="<?php echo $_SESSION["uname"]?>">
        <input type="submit" id="btnUpdate" value="Update">

    </form>
</body>
</html>



