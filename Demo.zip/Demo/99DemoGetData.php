<?php 
    header("content-Type: application/json");
    echo '[{"No": 1, "Name": "Mohit", "Role": "user", "IsActive": "true"},{"No": 2, "Name": "Rohit", "Role": "user", "IsActive": "true"},{"No": 3, "Name": "Purohit", "Role": "user", "IsActive": "true"}]';

?>