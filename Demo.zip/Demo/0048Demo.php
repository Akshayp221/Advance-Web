<?php 
//    $con =  mysqli_connect("localhost","root","manager","karad");
//    $result  =  mysqli_query($con,"select * from Emp");
//    while ($currentRecord = mysqli_fetch_row($result)) {
//         echo "<h1>" .$currentRecord[1]  ."</h1>";
//    }
//    mysqli_close($con);


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>DB Check</title>
</head>
<body>
    <table border="2">
        <?php

            $con =  mysqli_connect("localhost","root","manager","karad");
            $result  =  mysqli_query($con,"select * from Emp");
            while ($currentRecord = mysqli_fetch_row($result)) {
                echo "<tr>". 
                        "<td>" .$currentRecord[0]  . "</td>".
                        "<td>" .$currentRecord[1]  . "</td>".
                        "<td>" .$currentRecord[2]  . "</td>".
                     "</tr>";
            }
            mysqli_close($con);
        ?>
    </table>
</body>
</html>