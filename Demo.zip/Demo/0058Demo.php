<!DOCTYPE html>
<html lang="en">
<head>
    <title>Show Cookie</title>
</head>
<body>
    <?php 
        //echo print_r($_COOKIE);
        //echo $_COOKIE[0];
        if(isset($_COOKIE["item1"]))
        {
            echo "You Stored ";
            echo "<h2> ITEM 1 = " .$_COOKIE["item1"] . " </h2>";
            echo "<h2> ITEM 2 = " .$_COOKIE["item2"] . " </h2>";
        }
        else
        {
            echo "<h1>You dont have any preferences stored!</h1>";
        }
    ?>
</body>
</html>