<?php
    // $file = fopen("test.txt", "w");              //or die("Something Wrong!");
    // fwrite($file,"Hello How Are You");
    // fclose($file);
    // echo "Done!";

    // $file = fopen("test.txt", "r") ;                //or die("Something Wrong!");
    // echo fgets($file);
    // fclose($file);
?>