<?php
    session_start();
    if(isset($_SESSION["uname"]))
    {
        if($_SESSION["role"] == "admin")
        {
            //???
            
        }
        else
        {
            header("location:99DemoLogin.php");    
        }
    }
    else
    {
        header("location:99DemoLogin.php");
    }
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Dashboard</title>
    <script src="jquery-1.8.3.min.js"></script>
    <script src="jquery.tmpl.js"></script>
    <script type="text/html" id="myTemplate">
        <tr>
            <td>{{= No}}</td>
            <td>{{= Name}}</td>
            <td>{{= Role}}</td>
            <td>{{= IsActive}}</td>
            <td> <a href="99DemoDelete.php?No={{= No}}">Delete</a> </td>
        </tr>
    </script>
    <script>
        $(document).ready(function(){
            $.ajax({
                url: '99DemoGetData.php',
                type: 'GET',
                contentType: 'application/json',
                success : function (result){
                    $('#myTemplate').render(result).appendTo('#myTab');
                },
                error : function (error){
                  alert   ("ERR");
                }
            });
        });
    </script>
</head>
<body>
    <h1><?php echo "Welcome " . $_SESSION["uname"]; ?> &nbsp;<a href="99DemoLogout.php">Log Out</a>  </h1>
    

    <table id="myTab"border="2">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Role</th>
            <th>IsActive</th>
            <th></th>
        </tr>
    </table>
    
</body>
</html>