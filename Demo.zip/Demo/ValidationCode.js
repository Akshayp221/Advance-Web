function ValidateForEmpty(ctrlToValidate, spnForErr, errMessage)
    {
        var refToSpan = document.getElementById(spnForErr);
        var refToTextBox = document.getElementById(ctrlToValidate);

        var dataFromTextBox = refToTextBox.value;

        if(dataFromTextBox=="")
        {
            refToSpan.innerText = errMessage;
        }
        else
        {   
            refToSpan.innerText = "";
            window.alert("Hello " + dataFromTextBox);
        }
    } 
