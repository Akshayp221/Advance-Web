<!DOCTYPE html>
<html lang="en">
<head>
    <title>DB Check</title>
</head>
<body>
    <form action="0051Demo.php" method="POST">
        <input type="submit" value="Fetch Table Data" name="btnSubmit" id="btnSubmit">
        <br>
        <table border="2">
            <?php
                if(isset($_POST["btnSubmit"]))
                {
                    
                    $con =  mysqli_connect("localhost","root","manager","karad");
                    echo mysqli_connect_error();
    
                    echo mysqli_error($con);
                    $result  =  mysqli_query($con,"select * from Emp");
                    while ($currentRecord = mysqli_fetch_row($result)) {
                        echo "<tr>". 
                                "<td>" .$currentRecord[0]  . "</td>".
                                "<td>" .$currentRecord[1]  . "</td>".
                                "<td>" .$currentRecord[2]  . "</td>".
                            "</tr>";
                    }
                    mysqli_close($con);
                }
            
            ?>
        </table>


    </form>
</body>
</html>