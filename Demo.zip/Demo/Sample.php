<?php

$xml = simplexml_load_file('Sample.xml');

echo '<h2>Students</h2>';

$list = $xml->student;

for ($i = 0; $i < count($list); $i++) {

    echo '<b>No:</b> ' . $list[$i]->rollno . '<br>';

    echo 'Name: ' . $list[$i]->name . '<br>';

    echo 'Address: ' . $list[$i]->address . '<br><br>';

}
?>