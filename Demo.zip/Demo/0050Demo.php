<?php 
    if(isset($_POST["btnSubmit"]))
    {
        $con =  mysqli_connect("localhost","root","manager","karad");
//        $query = "insert into Emp(No,Name,Address) values(4,'rahul','pune')";

        $query = "insert into Emp(No,Name,Address) values(" . 
                $_POST["No"] .
                ",'". $_POST["Name"] ."','". 
                $_POST["Address"] ."')";

        echo $query;
       $result  =  mysqli_query($con,$query);
       
    
       echo mysqli_affected_rows($con);

       mysqli_close($con);
        
       //header("location:0048Demo.php");
    }
    else
    {
        header("location:0049Demo.html");
    }
?>
