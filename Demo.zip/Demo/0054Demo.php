<?php 
    
    $didyoulogin = false;
    
    session_start();

    if(isset($_POST["btnLogout"]))  
    {
        $didyoulogin = false;
        unset($_SESSION["uname"]);
        header("location:0055Login.php");
    }
    else
    {
        if(isset($_SESSION["uname"]))  
        {
            $didyoulogin = true;
        }
        else
        {
            header("location:0055Login.php");
        }  
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Secure</title>
</head>
<body>
    <form action="0054Demo.php" method="POST">
        <?php 
            if($didyoulogin == true)
            {
                echo "<h1>Welcome   ". $_SESSION["uname"]." </h1>";
                echo  "<h1>This is very very safe page</h1>";
            }
        ?>
        <input value="Log out" type="submit" name="btnLogout" id="btnLogout">
    </form>
</body>
</html>




