<!DOCTYPE html>
<html lang="en">
<head>
    <title>PHP Test</title>
</head>
<body>
    <?php 
        $v1 = 100;
        $v2 = 200;
        $result = $v1    + $v2;
        echo '<b>'. $result. '</b>';
        // echo "<h1>Hello PHP From Server</h1>";
    ?>
</body>
</html>