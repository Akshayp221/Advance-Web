<?php
    echo "Hello ". $_GET["mydata"]["Name"];
    //echo print_r ($_GET);
?>